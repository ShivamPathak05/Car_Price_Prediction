from django.contrib import admin
from carapp.models import NewUser

# Register your models here.
admin.site.register(NewUser)
